package com.example.calculadoraimc;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private EditText editPeso;
    private EditText editAltura;
    private TextView txtResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editPeso = findViewById(R.id.editPeso);
        editAltura = findViewById(R.id.editAltura);
        txtResultado = findViewById(R.id.txtResultado);
    }

    public void calcularImc(View view) {
        try {
            double peso = Double.parseDouble(editPeso.getText().toString());
            double altura = Double.parseDouble(editAltura.getText().toString());

            double imc = peso / (altura * altura);

            DecimalFormat df = new DecimalFormat("#.##");
            String imcFormatted = df.format(imc);

            if (imc < 18.5) {
                txtResultado.setText("Abaixo do peso, IMC = " + imcFormatted);
            } else if (imc >= 18.5 && imc <= 24.99) {
                txtResultado.setText("Peso normal, IMC = " + imcFormatted);
            } else if (imc >= 25 && imc <= 29.99) {
                txtResultado.setText("Acima do peso, IMC = " + imcFormatted);
            } else if (imc >= 30 && imc <= 34.99) {
                txtResultado.setText("Obesidade I, IMC = " + imcFormatted);
            } else if (imc >= 35 && imc <= 39.99) {
                txtResultado.setText("Obesidade II, IMC = " + imcFormatted);
            } else {
                txtResultado.setText("Obesidade extrema, IMC = " + imcFormatted);
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Por favor, insira valores válidos.", Toast.LENGTH_SHORT).show();
        }
    }
}
